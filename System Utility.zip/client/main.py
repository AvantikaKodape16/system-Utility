import os
import json
import time
import uuid
import platform
import requests
from pathlib import Path

INTERVAL_MINUTES = 15
ENDPOINT = "http://127.0.0.1:8000/report"
MACHINE_ID_PATH = Path.home() / ".system_utility_machine_id"

def get_machine_id():
    if MACHINE_ID_PATH.exists():
        return MACHINE_ID_PATH.read_text()
    mid = str(uuid.uuid4())
    MACHINE_ID_PATH.write_text(mid)
    return mid

def check_disk_encryption():
    system = platform.system()
    if system == "Windows":
        # BitLocker check (admin required)
        try:
            import subprocess
            out = subprocess.check_output(
                'manage-bde -status', shell=True, encoding="utf-8", errors="ignore"
            )
            return "Fully Encrypted" if "Percentage Encrypted: 100%" in out else "Not Fully Encrypted"
        except Exception as e:
            return f"Unknown ({e})"
    elif system == "Darwin":
        try:
            import subprocess
            out = subprocess.check_output(
                'fdesetup status', shell=True, encoding="utf-8", errors="ignore"
            )
            return "Enabled" if "FileVault is On" in out else "Disabled"
        except Exception as e:
            return f"Unknown ({e})"
    elif system == "Linux":
        # LUKS check for root
        try:
            import subprocess
            out = subprocess.check_output(
                'lsblk -o NAME,MOUNTPOINT,TYPE', shell=True, encoding="utf-8", errors="ignore"
            )
            return "Check manually (LUKS/cryptsetup)" # Simplified for demo
        except Exception as e:
            return f"Unknown ({e})"
    else:
        return "Unknown OS"

def check_os_update():
    system = platform.system()
    if system == "Windows":
        return "Check via Windows Update (manual demo)"
    elif system == "Darwin":
        try:
            import subprocess
            out = subprocess.check_output(
                'softwareupdate -l', shell=True, encoding="utf-8", errors="ignore"
            )
            if "No new software available" in out:
                return "Up to date"
            else:
                return "Updates available"
        except Exception as e:
            return f"Unknown ({e})"
    elif system == "Linux":
        # For demo, Ubuntu/Debian
        try:
            import subprocess
            out = subprocess.check_output(
                'apt list --upgradable', shell=True, encoding="utf-8", errors="ignore"
            )
            if "upgradable" in out:
                return "Updates available"
            else:
                return "Up to date"
        except Exception as e:
            return f"Unknown ({e})"
    else:
        return "Unknown OS"

def check_antivirus():
    system = platform.system()
    if system == "Windows":
        try:
            import subprocess
            out = subprocess.check_output(
                'powershell Get-MpComputerStatus', shell=True, encoding="utf-8", errors="ignore"
            )
            return "Enabled" if "AMServiceEnabled : True" in out else "Disabled"
        except Exception as e:
            return f"Unknown ({e})"
    elif system == "Darwin":
        # Most macOS don't have default AV
        return "No default AV"
    elif system == "Linux":
        # Check for ClamAV or similar
        try:
            import subprocess
            out = subprocess.check_output(
                'systemctl is-active clamav-daemon', shell=True, encoding="utf-8", errors="ignore"
            )
            return "Enabled" if "active" in out else "Not running"
        except Exception as e:
            return f"Unknown ({e})"
    else:
        return "Unknown OS"

def check_sleep_settings():
    system = platform.system()
    if system == "Windows":
        try:
            import subprocess
            out = subprocess.check_output(
                'powercfg /query SCHEME_CURRENT SUB_SLEEP STANDBYIDLE', shell=True, encoding="utf-8", errors="ignore"
            )
            # Parse output, simplified
            if "Power Setting Index: 0x0000000a" in out or "Power Setting Index: 0x00000005" in out:
                return "<= 10 minutes"
            else:
                return "Check required"
        except Exception as e:
            return f"Unknown ({e})"
    elif system == "Darwin":
        try:
            import subprocess
            out = subprocess.check_output(
                'pmset -g | grep sleep', shell=True, encoding="utf-8", errors="ignore"
            )
            # Example output: " sleep 10"
            minutes = [int(s) for s in out.split() if s.isdigit()]
            if minutes and minutes[0] <= 10:
                return "<= 10 minutes"
            else:
                return "Greater than 10 minutes"
        except Exception as e:
            return f"Unknown ({e})"
    elif system == "Linux":
        # Assume gsettings (GNOME)
        try:
            import subprocess
            out = subprocess.check_output(
                'gsettings get org.gnome.settings-daemon.plugins.power sleep-inactive-ac-timeout', shell=True, encoding="utf-8", errors="ignore"
            )
            minutes = int(out.strip()) // 60
            return "<= 10 minutes" if minutes <= 10 else "Greater than 10 minutes"
        except Exception as e:
            return f"Unknown ({e})"
    else:
        return "Unknown OS"

def collect_status():
    return {
        "machine_id": get_machine_id(),
        "os": platform.system(),
        "os_version": platform.version(),
        "disk_encryption": check_disk_encryption(),
        "os_update": check_os_update(),
        "antivirus": check_antivirus(),
        "sleep_settings": check_sleep_settings(),
    }

def load_last_report():
    try:
        return json.loads(Path("last_report.json").read_text())
    except Exception:
        return None

def save_last_report(report):
    Path("last_report.json").write_text(json.dumps(report, indent=2))

def main_loop():
    while True:
        status = collect_status()
        last = load_last_report()
        if status != last:
            try:
                resp = requests.post(ENDPOINT, json=status, timeout=10)
                print(f"Reported: {status} / Server: {resp.text}")
            except Exception as e:
                print(f"Failed to send: {e}")
            save_last_report(status)
        else:
            print("No change in system status.")
        time.sleep(INTERVAL_MINUTES * 60)

if __name__ == "__main__":
    main_loop()