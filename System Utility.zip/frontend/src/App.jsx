import React, { useEffect, useState } from "react";

function flagIssues(machine) {
  let issues = [];
  if (!machine.disk_encryption.toLowerCase().includes("enable") && !machine.disk_encryption.toLowerCase().includes("fully encrypted"))
    issues.push("Disk Encryption");
  if (!machine.os_update.toLowerCase().includes("up to date"))
    issues.push("OS Update");
  if (!machine.antivirus.toLowerCase().includes("enable"))
    issues.push("Antivirus");
  if (!machine.sleep_settings.includes("10"))
    issues.push("Sleep Settings");
  return issues.join(", ");
}

function App() {
  const [machines, setMachines] = useState([]);
  const [osFilter, setOsFilter] = useState("");
  const [issueFilter, setIssueFilter] = useState("");
  useEffect(() => {
    let url = "http://localhost:8000/machines";
    let query = [];
    if (osFilter) query.push(`os=${osFilter}`);
    if (issueFilter) query.push(`issue=${issueFilter}`);
    if (query.length) url += "?" + query.join("&");
    fetch(url)
      .then((r) => r.json())
      .then(setMachines);
  }, [osFilter, issueFilter]);
  return (
    <div style={{ margin: 20 }}>
      <h2>System Utility Admin Dashboard</h2>
      <div>
        <label>Filter by OS: </label>
        <select onChange={e => setOsFilter(e.target.value)} value={osFilter}>
          <option value="">All</option>
          <option value="Windows">Windows</option>
          <option value="Darwin">macOS</option>
          <option value="Linux">Linux</option>
        </select>
        <label style={{marginLeft:10}}>Flagged Issue: </label>
        <select onChange={e => setIssueFilter(e.target.value)} value={issueFilter}>
          <option value="">Any</option>
          <option value="not">Any Issue</option>
          <option value="disable">Disabled</option>
          <option value="available">Updates Available</option>
          <option value="greater">Sleep > 10 min</option>
        </select>
      </div>
      <table border={1} cellPadding={6} style={{marginTop:12, minWidth:800}}>
        <thead>
          <tr>
            <th>Machine ID</th>
            <th>OS</th>
            <th>OS Version</th>
            <th>Disk Encryption</th>
            <th>OS Update</th>
            <th>Antivirus</th>
            <th>Sleep</th>
            <th>Last Check-in</th>
            <th>Config Issues</th>
          </tr>
        </thead>
        <tbody>
          {machines.map(m => (
            <tr key={m.machine_id}>
              <td>{m.machine_id}</td>
              <td>{m.os}</td>
              <td>{m.os_version}</td>
              <td>{m.disk_encryption}</td>
              <td>{m.os_update}</td>
              <td>{m.antivirus}</td>
              <td>{m.sleep_settings}</td>
              <td>{m.timestamp.replace("T"," ").slice(0,19)}</td>
              <td style={{color:"red"}}>{flagIssues(m)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default App;