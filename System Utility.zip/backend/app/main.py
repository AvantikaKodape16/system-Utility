from fastapi import FastAPI, Request, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime
import sqlite3

app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], allow_methods=["*"], allow_headers=["*"]
)

DB = "status.db"

def init_db():
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute(
        """CREATE TABLE IF NOT EXISTS reports (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            machine_id TEXT,
            os TEXT,
            os_version TEXT,
            disk_encryption TEXT,
            os_update TEXT,
            antivirus TEXT,
            sleep_settings TEXT,
            timestamp TEXT
        )"""
    )
    conn.commit()
    conn.close()

init_db()

class StatusReport(BaseModel):
    machine_id: str
    os: str
    os_version: str
    disk_encryption: str
    os_update: str
    antivirus: str
    sleep_settings: str

@app.post("/report")
def report_status(report: StatusReport):
    now = datetime.utcnow().isoformat()
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute("INSERT INTO reports (machine_id, os, os_version, disk_encryption, os_update, antivirus, sleep_settings, timestamp) VALUES (?,?,?,?,?,?,?,?)",
              (report.machine_id, report.os, report.os_version, report.disk_encryption, report.os_update, report.antivirus, report.sleep_settings, now))
    conn.commit()
    conn.close()
    return {"status": "ok"}

@app.get("/machines")
def list_machines(os: Optional[str]=None, issue: Optional[str]=None):
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    q = "SELECT * FROM (SELECT * FROM reports ORDER BY timestamp DESC) GROUP BY machine_id"
    rows = c.execute(q).fetchall()
    result = []
    for row in rows:
        data = {
            "machine_id": row[1], "os": row[2], "os_version": row[3],
            "disk_encryption": row[4], "os_update": row[5],
            "antivirus": row[6], "sleep_settings": row[7], "timestamp": row[8]
        }
        if os and data["os"] != os:
            continue
        # Simple issue flag: if any setting is not "Enabled"/"Fully Encrypted"/"Up to date"/"< 10 minutes"
        if issue:
            flagged = False
            for k, v in data.items():
                if k in ["disk_encryption","os_update","antivirus","sleep_settings"] and issue.lower() in v.lower():
                    flagged = True
            if not flagged:
                continue
        result.append(data)
    conn.close()
    return result

@app.get("/export")
def export_csv():
    import csv
    from fastapi.responses import StreamingResponse
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    rows = c.execute("SELECT * FROM reports").fetchall()
    conn.close()
    def generate():
        writer = csv.writer([])
        yield "id,machine_id,os,os_version,disk_encryption,os_update,antivirus,sleep_settings,timestamp\n"
        for row in rows:
            yield ",".join([str(x).replace(",",";") for x in row]) + "\n"
    return StreamingResponse(generate(), media_type="text/csv")